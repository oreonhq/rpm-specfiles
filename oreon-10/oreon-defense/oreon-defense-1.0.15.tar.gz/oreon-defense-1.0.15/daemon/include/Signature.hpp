#pragma once
#include <string>

namespace oreon {

// Ed25519 detached signature check. The key is a PEM public key file
// (as written by `openssl pkey -pubout`). The signature is 64 raw bytes
// or the same bytes in base64.
bool verifyEd25519(const std::string& publicKeyPem, const std::string& data,
                   const std::string& signature, std::string* err = nullptr);

bool readWholeFile(const std::string& path, std::string& out, size_t maxBytes = 64 * 1024 * 1024);
// Write to path.tmp, fsync, rename over path.
bool writeFileAtomic(const std::string& path, const std::string& data, unsigned mode = 0644);

} // namespace oreon
