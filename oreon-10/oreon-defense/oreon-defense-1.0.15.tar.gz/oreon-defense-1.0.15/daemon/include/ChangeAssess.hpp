#pragma once
#include "SystemTrust.hpp"
#include <oreon/Types.hpp>
#include <string>
#include <vector>

namespace oreon {
namespace change {

// What kind of guarded file changed. Decided from the path only.
enum class FileKind {
  Passwd, Shadow, Group, GShadow, Sudoers, AuthorizedKeys, Preload, Canary, Persistence
};
FileKind kindOf(const std::string& path);

// Content checks that run for every change, whoever made it. Even a
// trusted tool can be told to do something harmful, so the strongest
// signals always alert.
struct Delta {
  std::vector<std::string> critical;  // always alert (plain sentences)
  bool criticalIsTop{false};          // a uid 0 account, empty root password, root key
  std::vector<std::string> notes;     // benign summary (new users and so on)
  std::vector<std::string> grants;    // principals newly given full sudo rights (no NOPASSWD)
  bool malformed{false};
  std::string malformedWhy;
};
Delta analyze(const std::string& path, const std::string& before, const std::string& after);

// One change to a guarded file, with whoever made it.
struct Event {
  std::string path;
  std::string before;
  std::string after;
  bool attributed{false};           // a writer pid was seen
  trust::ActorVerdict actor;        // valid when attributed
  bool packageCopy{false};          // content equals the rpm database copy
};

struct Verdict {
  bool alert{false};
  Severity severity{Severity::Info};
  std::string category;             // privesc, persistence, ransomware
  std::string title;                // short, plain
  std::string message;              // one plain sentence
  std::string detail;               // diff summary
  std::vector<std::string> reasons; // why, for the log
  bool killWriter{false};           // stop the writer if the policy allows
};

// The single decision used by every file guard:
//  (a) trusted writer and trusted ancestry: info only
//  (b) untrusted or non-root writer or ancestor: alert (and stop the
//      writer for ransomware canaries)
//  (c) no writer known: content verification (rpm copy, account file
//      structure, risky deltas); alert only on a suspicious delta
// The critical content signals alert in every case.
Verdict assess(const Event& e);

// True when the file content matches the sha256 the rpm database records.
bool matchesRpm(const std::string& path);

} // namespace change
} // namespace oreon
