#pragma once
#include <oreon/Types.hpp>
#include <string>

namespace oreon {

// Result of running all engines (ClamAV, YAML rules) on one file.
struct Detection {
  bool matched{false};
  std::string name;       // virus or rule name
  std::string ruleId;     // rule id or "clamav"
  std::string detail;
  std::string engine;     // "clamav" or "rules"
  std::string description;
  Severity severity{Severity::High};
  bool kill{true};
  bool heuristic{false};  // low confidence, never blocks or quarantines
  bool cacheable{true};   // a clean verdict may be cached by inode
};

} // namespace oreon
