#pragma once
#include "RuleEngine.hpp"
#include <string>
#include <mutex>
#include <thread>
#include <atomic>
#include <functional>
#include <cstdint>

namespace oreon {

// Fetches signed rules from the feed (https://od-rules.oreonhq.com):
//   manifest.json   {"format":1,"version":N,"sha256":"...","published":"..."}
//   rules.yaml      the rule document, its own "version:" must equal N
//   rules.yaml.sig  Ed25519 signature over rules.yaml (64 raw bytes)
// Good downloads are stored as rules-N.yaml(.sig) and a "current" pointer
// is swapped atomically. Anything that fails a check is thrown away.
class RuleUpdater {
public:
  struct Status {
    std::string url;
    int64_t version{0};
    std::string published;
    int64_t lastCheck{0};
    int64_t lastUpdate{0};
    std::string lastResult;
    std::string lastError;
    bool running{false};
    bool keyPresent{false};
  };
  using RulesCb = std::function<void(const RuleSet& rs)>;
  using DoneCb = std::function<void(const Status& st, bool changed)>;

  ~RuleUpdater();
  void configure(const std::string& baseUrl, const std::string& publicKeyPath,
                 const std::string& feedDir);
  void setRulesCallback(RulesCb cb) { rulesCb_ = std::move(cb); }
  void setDoneCallback(DoneCb cb) { doneCb_ = std::move(cb); }

  // Load the last good feed from disk (signature checked again).
  bool loadStored(RuleSet& out);
  // Run one update in the background. Returns false if one is running.
  bool startAsync(bool force);
  // Blocking update. Returns true when new rules were applied.
  bool updateNow(bool force, std::string* err = nullptr);
  Status status() const;
  void join();

private:
  bool fetch(const std::string& url, std::string& out, size_t maxBytes, std::string* err);
  void saveState();
  void loadState();
  bool verifyBlob(const std::string& yaml, const std::string& sig, std::string* err) const;

  std::string baseUrl_;
  std::string keyPath_;
  std::string feedDir_;
  std::string keyPem_;
  RulesCb rulesCb_;
  DoneCb doneCb_;
  mutable std::mutex mu_;
  Status st_;
  std::thread thr_;
  std::atomic<bool> running_{false};
};

} // namespace oreon
