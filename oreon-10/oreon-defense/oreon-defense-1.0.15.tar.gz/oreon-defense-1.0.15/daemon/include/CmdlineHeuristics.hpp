#pragma once
#include <string>
#include <vector>

namespace oreon {
namespace heuristics {

// Reverse shell and remote control patterns, judged on argv and the real
// program (exe) instead of substrings of the joined command line. A
// program merely naming a file such as /usr/bin/mkfifo (cp and
// dracut-install do that while building an initramfs) never matches;
// "rsync -e" is not "nc -e" and "ssh -i" is not "sh -i".
struct Hit {
  bool matched{false};
  std::string pattern;
};

// argv as read from /proc/<pid>/cmdline, exe the program path (host or
// inner, only its file name is used).
Hit strongProcessPattern(const std::vector<std::string>& argv, const std::string& exe);

// Inline code handed to an interpreter (sh -c, python -c, perl -e ...),
// empty when there is none.
std::string inlineCode(const std::vector<std::string>& argv, const std::string& exe);

} // namespace heuristics
} // namespace oreon
