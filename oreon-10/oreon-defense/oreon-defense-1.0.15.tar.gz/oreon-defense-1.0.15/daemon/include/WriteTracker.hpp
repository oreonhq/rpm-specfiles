#pragma once
#include "SystemTrust.hpp"
#include <atomic>
#include <deque>
#include <map>
#include <mutex>
#include <string>
#include <thread>
#include <vector>

namespace oreon {

// Tells who wrote a file. inotify, which the guards use to see changes,
// carries no pid, so this runs a fanotify notification group on the same
// folders and judges the writer the moment the kernel reports it, while
// the process (or its exec snapshot) is still there.
//
// Modes, best first:
//  - FAN_REPORT_DFID_NAME (kernel 5.9+): modify, close-write, create and
//    moved-to with the file name, so renames (useradd writes passwd+ and
//    renames it over passwd) are attributed exactly
//  - plain fd mode (older kernels): modify and close-write only; a rename
//    is attributed to the latest writer in the same folder
// FAN_REPORT_PIDFD (kernel 5.15+) is requested when available; the pidfd
// is closed right away. Pid reuse is handled by start time checks.
// Needs CAP_SYS_ADMIN; without it attribution is simply unavailable and the
// guards fall back to content checks.
class WriteTracker {
public:
  struct Write {
    std::string path;       // full path (or folder when the name is unknown)
    std::string dir;
    int64_t atMs{0};
    trust::ActorVerdict actor;
  };

  bool start(const std::vector<std::string>& dirs);
  void stop();
  bool running() const { return running_; }
  std::string mode() const { return mode_; }

  // Latest writer of path within windowMs, falling back to the latest
  // writer in the same folder (temp file then rename). False if none.
  bool lookup(const std::string& path, int64_t windowMs, Write& out) const;

  // For tests and for other event sources that know the pid.
  void record(const std::string& path, pid_t pid);
  void recordVerdict(const std::string& path, const trust::ActorVerdict& v);

private:
  void loop();
  void handleBuffer(const char* buf, ssize_t len);

  int fd_{-1};
  bool fidMode_{false};
  std::atomic<bool> running_{false};
  std::string mode_{"off"};
  std::thread thr_;
  mutable std::mutex mu_;
  std::deque<Write> recent_;
  std::map<std::string, std::string> handles_;  // dir handle bytes -> dir path
};

} // namespace oreon
