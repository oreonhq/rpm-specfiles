#pragma once
#include <oreon/Types.hpp>
#include <string>
#include <vector>
#include <regex>
#include <optional>
#include <mutex>
#include <memory>
#include <sys/types.h>
#include <sys/stat.h>

namespace oreon {

struct Pattern {
  std::string text;
  bool literal{true};                 // plain substring, no regex needed
  std::shared_ptr<std::regex> re;     // compiled when not literal
};

struct Rule {
  std::string id;
  std::string name;
  std::string description;
  Severity severity{Severity::Medium};
  std::vector<std::string> hashes;      // sha256
  std::vector<std::string> pathPatterns;
  std::vector<std::string> cmdlinePatterns;
  std::vector<std::string> namePatterns;
  std::vector<std::string> contentPatterns; // simple substring / regex
  // Low confidence checks. A hit is reported as "suspicious", never
  // blocked, quarantined or killed.
  bool elfHeuristic{false};
  bool autostartHeuristic{false};
  bool enabled{true};
  bool kill{false};  // kill matching processes when killMalicious is on
  // A cmdline match alone also hits shells and greps that only mention the
  // pattern, so it only kills when the rule asks for it.
  bool killCmdline{false};

  // compiled forms
  std::vector<Pattern> pathRe, cmdlineRe, nameRe, contentRe;
};

struct BlockEntry {
  std::string cidr;     // "203.0.113.7" or "198.51.100.0/24" or v6
  std::string reason;
};

struct RuleSet {
  int64_t version{0};
  std::string published;
  std::vector<Rule> rules;
  std::vector<BlockEntry> blocklist;
};

struct MatchResult {
  bool matched{false};
  Rule rule;
  std::string detail;
  // the hit came from a heuristic, not from a hash, content or path rule
  bool heuristic{false};
  // false when the verdict can change without the file content changing
  // (an ELF without the exec bit is looked at again once it is executable)
  bool cacheable{true};
};

// Who touched the file, when the caller knows it.
struct ScanContext {
  pid_t pid{0};      // opener from the fanotify event, 0 when unknown
  bool exec{false};  // the open is an exec
};

class RuleEngine {
public:
  // Parse a rule document. Returns false and fills err on bad input.
  static bool parse(const std::string& yamlText, RuleSet& out, std::string* err = nullptr);
  // Later sets override earlier rules with the same id; blocklists add up.
  static RuleSet merge(const std::vector<RuleSet>& sets);

  bool loadFile(const std::string& path);
  bool loadYaml(const std::string& yamlText);
  void setRuleSet(RuleSet rs);
  size_t ruleCount() const;
  int64_t version() const;
  std::vector<BlockEntry> blocklist() const;

  MatchResult matchFile(const std::string& path, const std::string& sha256 = "");
  // Same as matchFile but reads through an already open descriptor.
  MatchResult matchFd(int fd, const std::string& path, const ScanContext& ctx = {});
  MatchResult matchProcess(const std::string& name, const std::string& cmdline, const std::string& exe);
  std::vector<Rule> rules() const;
  void addAllowPath(const std::string& path);
  bool isAllowed(const std::string& path) const;
  bool needsHash() const;

private:
  MatchResult matchData(const std::string& path, const std::string& hash,
                        const std::string& head, bool isElf, int fd,
                        const struct stat* st, const ScanContext& ctx) const;
  static bool anyMatch(const std::vector<Pattern>& pats, const std::string& s);

  mutable std::mutex mu_;
  std::vector<Rule> rules_;
  int64_t version_{0};
  std::vector<BlockEntry> blocklist_;
  std::vector<std::string> allowPaths_;
};

} // namespace oreon
