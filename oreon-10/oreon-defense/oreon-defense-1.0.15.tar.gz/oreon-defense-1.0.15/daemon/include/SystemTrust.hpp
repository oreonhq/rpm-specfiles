#pragma once
#include <string>
#include <vector>
#include <sys/types.h>
#include <sys/stat.h>
#include <cstdint>

namespace oreon {

// Checks that tell normal system activity apart from a real drop:
// package managers, initramfs builders and installers copy plenty of ELF
// files and desktop entries around, and none of that should look like an
// attack. Everything here only ever lowers the weight of a heuristic hit.
// Hash and signature matches never go through these checks.
namespace trust {

// Folders where system tools stage files: dracut and kernel-install trees,
// dnf and PackageKit caches, rpm scratch files, akmods build roots.
bool systemStagingPath(const std::string& path);

// Places an unprivileged user can drop a file: /tmp, /var/tmp, /dev/shm,
// home folders (Downloads and Desktop included) and /run/user.
bool userWritableArea(const std::string& path);

// True when a non-root user could have put the file there: the file is
// owned by a non-root user, or its folder is owned by one, or the folder
// is group or world writable (like /tmp).
bool droppableByUser(const std::string& path, const struct stat& st);

// The file is a byte for byte copy of a system file with the same name,
// for example /var/tmp/x/usr/bin/cat and /usr/bin/cat, or a library that
// matches /usr/lib64/<name>. Only regular, root owned files under /usr
// count as the reference.
bool copyOfSystemFile(int fd, const std::string& path, const struct stat& st);


// An rpm transaction holds the rpmdb write lock. Cached for a couple of
// seconds.
bool packageTransactionActive();

// Result of looking at an XDG autostart desktop entry.
struct AutostartVerdict {
  bool suspicious{false};
  std::string reason;
};

// True for .desktop files inside an autostart folder.
bool isAutostartEntry(const std::string& path);

// Looks at the Exec line of an autostart entry. Entries that start a
// root owned program from /usr (or /opt), or that are identical to the
// copy in /etc/xdg/autostart or /usr/share/applications, are fine. It
// flags entries that run something from a user writable or hidden
// place, or that use download, decode or shell -c tricks.
AutostartVerdict checkAutostart(const std::string& path, const std::string& content);

// How much a running program can be trusted, judged by the file it runs
// and never by its name.
enum class SystemExe {
  No,           // not a system program (user area, writable, deleted, ...)
  RootPath,     // regular file in a system program folder; it and every
                // folder above it are root owned and not group or world
                // writable. Holds on live media too (squashfs or overlay).
  RpmVerified   // RootPath, and the rpm database lists the file with the
                // same sha256 digest
};

// Classify a program file. Resolves symlinks first.
SystemExe classifySystemExe(const std::string& path);

// Same check for a program inside a chroot, such as an installer target
// (/mnt/sysimage for Centrio, /tmp/calamares-root-XXXX for Calamares).
// root is the chroot root, inner the path inside it. The chroot root and
// its usr/ must be root owned and not group or world writable; folders
// above it only need to be root owned (when visible at all). The file and
// its folders up to the root must be root owned and not writable. rpm is
// asked with --root, so the target's own database decides; when rpm fails
// the root owned path verdict stands. Live processes are judged through
// /proc/<pid>/root instead of this path.
SystemExe classifyChrootExe(const std::string& root, const std::string& inner);

// A chroot root nobody but root could have built or changed.
bool trustedChrootRoot(const std::string& root);

// /proc/<pid>/root as seen from the host, "/" when not chrooted or unknown.
std::string processRoot(pid_t pid);

// The program a process runs, placed inside its own root. inner is the
// path the process itself sees (equal to host when not chrooted); the
// file is reachable at /proc/<pid>/exe whatever the daemon's mount
// namespace shows. ok is false when the process is gone.
struct ExeView {
  bool ok{false};
  std::string root{"/"};
  std::string inner;
  std::string host;
  std::string comm;
  bool raced{false};   // comm and exe never settled on one image
};
ExeView exeView(pid_t pid);

// Duplicate alert filter: true the first time a key is seen within
// windowSec seconds, false for repeats. Thread safe.
bool firstInWindow(const std::string& key, int64_t nowSec, int windowSec);

const char* systemExeName(SystemExe e);

// ---- one attribution and trust model for every engine ----
//
// assessActor judges the process behind an event and its whole ancestry:
//  - every link must run as root a locked down system program (host or
//    chroot aware, rpm digest checked against the right root); an
//    interpreter counts only when the script it runs passes the same check
//  - the chain ends trusted at pid 1 (services), a kernel thread, or the
//    user above an elevation done by a trusted set-user-ID root program
//  - a non-root writer, a non-root ancestor anywhere else, or an
//    untrusted link makes it Untrusted
//  - a process that is gone and was not seen at exec is Unattributed
enum class ActorTrust { Trusted, Untrusted, Unattributed };
const char* actorTrustName(ActorTrust t);

struct ActorVerdict {
  ActorTrust trust{ActorTrust::Unattributed};
  bool found{false};
  bool root{false};
  long uid{-1};
  int pid{0};
  int ppid{0};
  SystemExe exe{SystemExe::No};   // the actor's own binary
  bool shellLike{false};          // interpreter or relay
  std::string exePath;            // as seen from the host
  std::string chrootRoot;         // non-empty when chrooted
  std::vector<std::string> reasons;
  std::string summary() const;    // one line for the log
};

ActorVerdict assessActor(pid_t pid);

// Called on every exec (proc connector): remember the process and its
// parents so short lived writers can be judged after they exit.
void noteProcess(pid_t pid);
void forgetProcessesForTests();

enum class ProcessAction { Ignore, AlertOnly, AlertAndKill };

// Process hits (cmdline heuristics, process rules, ClamAV and file rules
// on the running binary, exec protection): Ignore when the whole chain is
// trusted and the binary itself did not match; otherwise alert, and kill
// only when asked and mayKill allows it.
ProcessAction decideProcess(const ActorVerdict& a, bool exeBad, bool wantKill);
const char* processActionName(ProcessAction a);

// The last word before any SIGKILL, whatever asked for it: never for a
// trusted chain, an rpm verified root binary, or a root locked down system
// binary that is not a shell or relay.
bool mayKill(const ActorVerdict& a);

// For on-access exec blocking: true when the program file is a system
// program (rpm verified or root owned system path) and not a shell or
// relay. Such a file is reported, never denied.
bool protectedSystemProgram(const std::string& path);

// For tests: replace the rpm lookup. The function gets a resolved path and
// returns the sha256 hex digest rpm records for it, or empty when rpm does
// not own the file or is not available. nullptr restores the real query.
// root is "/" for the host, or a chroot root (rpm --root).
using RpmDigestFn = std::string (*)(const std::string& root, const std::string& path);
void setRpmDigestFn(RpmDigestFn fn);

// True when rpm (for that root) records the same sha256 as the file has.
bool rpmFileDigestMatches(const std::string& root, const std::string& path);

// For tests only: also accept this uid where root ownership is required.
void setExtraTrustedOwnerForTests(uid_t uid);

// For tests: read processes from another procfs root. Empty restores
// /proc.
void setProcRoot(const std::string& root);

// For tests: show readlink results under real as if they were under shown,
// like a daemon whose mount namespace names paths it cannot open.
void setShownPathForTests(const std::string& real, const std::string& shown);

} // namespace trust
} // namespace oreon
