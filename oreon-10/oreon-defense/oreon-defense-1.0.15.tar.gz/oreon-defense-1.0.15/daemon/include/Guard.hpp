#pragma once
#include <oreon/Types.hpp>
#include <string>
#include <vector>
#include <deque>
#include <mutex>
#include <algorithm>
#include <cctype>

namespace oreon {
namespace guard {

// ---- exec protection policy (pure, unit tested) ----
//
// Downloads and temp dirs are a common place for a freshly dropped payload
// to be run. We only ever gate unknown, non package files. Trusted system
// tools (dracut, rpm) and files the user allowed always run.
enum class ExecDecision { Allow, Alert, Block };

struct ExecInputs {
  bool inDevShm{false};     // /dev/shm
  bool inTemp{false};       // /tmp or /var/tmp
  bool inDownloads{false};  // a user Downloads folder
  bool packageOwned{false}; // owned by an installed rpm
  bool trustedWriter{false};// started by a trusted actor (trust::assessActor)
  bool allowListed{false};  // on the user's exec allow list
  bool appImage{false};     // *.AppImage in Downloads
};

// Default policy: block in /dev/shm, alert (allow once) in Downloads,
// block in /tmp and /var/tmp. Known-good inputs always Allow.
inline ExecDecision execDecision(const ExecInputs& in) {
  if (in.packageOwned || in.trustedWriter || in.allowListed) return ExecDecision::Allow;
  if (in.inDevShm) return ExecDecision::Block;
  // Temp and Downloads: allow but flag, so normal builds and tools that run
  // from /tmp keep working. The user can tighten this with the allow list.
  if (in.inTemp || in.inDownloads) return ExecDecision::Alert;
  return ExecDecision::Alert;
}

// ---- ransomware name/extension heuristics (pure) ----
inline std::string lower(std::string s) {
  std::transform(s.begin(), s.end(), s.begin(), [](unsigned char c){ return std::tolower(c); });
  return s;
}

inline bool looksLikeRansomName(const std::string& path) {
  std::string p = lower(path);
  // a few well known ransom extensions
  static const char* exts[] = {".locked", ".crypt", ".crypted", ".encrypted",
    ".enc", ".cerber", ".locky", ".wncry", ".wcry", ".ryk", ".ryuk",
    ".conti", ".lockbit", ".crinf", ".r5a", ".xtbl", ".payransom"};
  for (auto e : exts) {
    size_t n = std::string(e).size();
    if (p.size() > n && p.compare(p.size() - n, n, e) == 0) return true;
  }
  // ransom note file names
  static const char* notes[] = {"readme_to_decrypt", "how_to_decrypt",
    "decrypt_instruction", "your_files_are_encrypted", "restore_files",
    "how_to_back_files", "recover_your_files", "!!!readme!!!"};
  std::string base = p;
  auto slash = base.find_last_of('/');
  if (slash != std::string::npos) base = base.substr(slash + 1);
  for (auto nte : notes)
    if (base.find(nte) != std::string::npos) return true;
  return false;
}

// Rolling detector of a process rewriting or renaming many user files in a
// short window. Thread safe. A burst is a lot of writes/renames quickly, or
// a few hits that look like ransom extensions or notes.
class RansomTracker {
public:
  struct Config {
    int windowMs{3000};
    int burstCount{40};     // this many file changes within the window
    int ransomNameHits{3};  // or this many ransom-looking names
  };

  RansomTracker() {}
  explicit RansomTracker(const Config& c) : cfg_(c) {}

  // Returns true the moment a burst threshold is crossed. op is "modify",
  // "create" or "rename". Resets its own count after firing.
  bool record(const std::string& path, const std::string& op, int64_t nowMs) {
    std::lock_guard<std::mutex> lk(mu_);
    while (!events_.empty() && nowMs - events_.front() > cfg_.windowMs) events_.pop_front();
    events_.push_back(nowMs);
    if (looksLikeRansomName(path)) ++ransomHits_;
    (void)op;
    bool fire = static_cast<int>(events_.size()) >= cfg_.burstCount ||
                ransomHits_ >= cfg_.ransomNameHits;
    if (fire) { events_.clear(); ransomHits_ = 0; }
    return fire;
  }

  void reset() {
    std::lock_guard<std::mutex> lk(mu_);
    events_.clear();
    ransomHits_ = 0;
  }

private:
  Config cfg_;
  std::mutex mu_;
  std::deque<int64_t> events_;
  int ransomHits_{0};
};

// ---- persistence diff (pure) ----
// A short human summary of what changed between two versions of a file, for
// the GUI. Reports counts of added and removed lines and the first example
// of each. Empty when nothing changed.
struct PersistDiff {
  int added{0};
  int removed{0};
  std::string firstAdded;
  std::string firstRemoved;
  bool changed() const { return added > 0 || removed > 0; }
  std::string summary() const {
    std::string s;
    if (added) s += std::to_string(added) + " line(s) added";
    if (removed) { if (!s.empty()) s += ", "; s += std::to_string(removed) + " line(s) removed"; }
    if (!firstAdded.empty()) s += "; added: " + firstAdded;
    return s;
  }
};

inline std::vector<std::string> splitLines(const std::string& t) {
  std::vector<std::string> out;
  std::string cur;
  for (char c : t) {
    if (c == '\n') { out.push_back(cur); cur.clear(); }
    else cur += c;
  }
  if (!cur.empty()) out.push_back(cur);
  return out;
}

inline PersistDiff persistenceDiff(const std::string& oldText, const std::string& newText) {
  auto a = splitLines(oldText), b = splitLines(newText);
  PersistDiff d;
  for (const auto& line : b) {
    if (std::find(a.begin(), a.end(), line) == a.end()) {
      ++d.added;
      if (d.firstAdded.empty() && !line.empty()) d.firstAdded = line.substr(0, 120);
    }
  }
  for (const auto& line : a) {
    if (std::find(b.begin(), b.end(), line) == b.end()) {
      ++d.removed;
      if (d.firstRemoved.empty() && !line.empty()) d.firstRemoved = line.substr(0, 120);
    }
  }
  return d;
}

} // namespace guard
} // namespace oreon
