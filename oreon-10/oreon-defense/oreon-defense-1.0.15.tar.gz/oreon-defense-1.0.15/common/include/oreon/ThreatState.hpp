#pragma once
#include <oreon/Types.hpp>
#include <cstdint>
#include <vector>

namespace oreon {

// A threat keeps the machine "at risk" until the user (or auto quarantine)
// resolves it: quarantined, deleted, allowed or restored on purpose.
// Detected, blocked and killed all leave the file in place, so they count.
// Low confidence heuristic hits are listed but never mark the machine at risk.
inline bool isActiveThreat(const Threat& t) {
  if (t.heuristic || t.severity < Severity::Medium) return false;
  return t.action == ThreatAction::Detected || t.action == ThreatAction::Blocked ||
         t.action == ThreatAction::Killed;
}

inline uint64_t countActiveThreats(const std::vector<Threat>& threats) {
  uint64_t n = 0;
  for (const auto& t : threats) if (isActiveThreat(t)) ++n;
  return n;
}

} // namespace oreon
