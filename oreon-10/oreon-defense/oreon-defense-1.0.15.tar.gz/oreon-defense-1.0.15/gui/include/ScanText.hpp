#pragma once
#include <QCoreApplication>
#include <QLocale>
#include <QString>
#include <algorithm>

// Pure text helpers for the scan page, kept free of widgets so they can be
// unit tested.
namespace ScanText {

// The real number of detections for a scan: the daemon's counter, or the
// detections the page actually received for that scan (ClamAV and rule
// hits alike), whichever is higher. The label must never claim fewer
// threats than the results table lists.
inline int detectionCount(qint64 daemonCount, int listed) {
  const qint64 n = std::max<qint64>(daemonCount < 0 ? 0 : daemonCount, listed < 0 ? 0 : listed);
  return n > 1000000 ? 1000000 : int(n);
}

inline QString threats(int n) {
  if (n <= 0) return QCoreApplication::translate("ScansPage", "no threats found");
  if (n == 1) return QCoreApplication::translate("ScansPage", "1 threat found");
  return QCoreApplication::translate("ScansPage", "%1 threats found").arg(QLocale().toString(n));
}

inline QString finished(bool cancelled, int n) {
  return (cancelled ? QCoreApplication::translate("ScansPage", "Scan cancelled")
                    : QCoreApplication::translate("ScansPage", "Scan finished"))
         + QStringLiteral(", ") + threats(n);
}

} // namespace ScanText
