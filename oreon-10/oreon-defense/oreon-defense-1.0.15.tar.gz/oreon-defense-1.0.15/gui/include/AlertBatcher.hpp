#pragma once
#include <QHash>
#include <QJsonObject>
#include <QList>
#include <QString>
#include <QStringList>

// Turns the stream of threat events from the daemon into a few desktop
// notifications. Events that arrive close together (a package update, a
// folder full of samples) are collected for a short window and shown as
// one notification. Low confidence hits ("suspicious") are also rate
// limited, and the same file and rule is only announced once in a while.
// Plain QtCore so it can be unit tested without a desktop.
class AlertBatcher {
public:
  struct Alert {
    bool summary{false};   // more than one item
    bool strong{false};    // real threat (signature or high rule) vs suspicious
    QJsonObject threat;    // the item when summary is false
    int count{0};
    int quarantined{0};
    int blocked{0};
    int killed{0};
    QStringList paths;     // a few example paths for a summary
  };

  static constexpr int kWindowMs = 1500;
  static constexpr qint64 kDedupeMs = 10 * 60 * 1000;
  static constexpr qint64 kWeakGapMs = 5 * 60 * 1000;

  // Real threats: ClamAV signatures and high or critical rule matches, and
  // anything the daemon already quarantined, blocked or killed.
  // Heuristic hits are never strong.
  static bool isStrong(const QJsonObject& threat);

  // Queue one event. Returns true when the caller should start the flush
  // timer (first event of a new burst).
  bool add(const QJsonObject& threat, qint64 nowMs);

  // Close the current burst and return what should be shown.
  QList<Alert> flush(qint64 nowMs);

  // Suspicious items held back by the rate limit so far.
  int held() const { return weakHeld_; }

private:
  static Alert build(const QList<QJsonObject>& items, bool strong, int extra);

  QList<QJsonObject> strong_;
  QList<QJsonObject> weak_;
  QHash<QString, qint64> seen_;
  qint64 lastWeakShown_{-1};
  int weakHeld_{0};
  bool armed_{false};
};
