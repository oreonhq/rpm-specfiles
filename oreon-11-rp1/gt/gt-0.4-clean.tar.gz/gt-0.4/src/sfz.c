#define LOADER
#include "sfz2pat.c"
