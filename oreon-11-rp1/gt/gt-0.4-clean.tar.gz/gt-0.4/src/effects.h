
#define HALL1 ((1<<4)|0)
#define HALL2 ((1<<4)|1)
#define ROOM1 ((2<<4)|0)
#define ROOM2 ((2<<4)|1)
#define ROOM3 ((2<<4)|2)
#define STAGE1 ((3<<4)|0)
#define STAGE2 ((3<<4)|1)
#define PLATE ((4<<4)|0)

#define DELAYLCR ((5<<4)|0)
#define DELAYLR ((6<<4)|0)
#define ECHO ((7<<4)|0)
#define CROSSDELAY ((8<<4)|0)
#define ER1 ((9<<4)|0)
#define ER2 ((9<<4)|1)
#define GATEREVERB ((10<<4)|0)
#define REVERSEGATE ((11<<4)|0)
#define KARAOKE1 ((20<<4)|0)
#define KARAOKE2 ((20<<4)|1)
#define KARAOKE3 ((20<<4)|2)

#define WHITEROOM ((16<<4)|0)
#define TUNNEL ((17<<4)|0)
#define CANYON ((18<<4)|0)
#define BASEMENT ((19<<4)|0)


#define CHORUS1 ((65<<4)|0)
#define CHORUS2 ((65<<4)|1)
#define CHORUS3 ((65<<4)|2)
#define CHORUS4 ((65<<4)|8)

#define CELESTE1 ((66<<4)|0)
#define CELESTE2 ((66<<4)|1)
#define CELESTE3 ((66<<4)|2)
#define CELESTE4 ((66<<4)|8)

#define FLANGER1 ((67<<4)|0)
#define FLANGER2 ((67<<4)|1)
#define FLANGER3 ((67<<4)|8)
#define SYMPHONIC ((68<<4)|0)
#define ROTARYSPEAKER ((69<<4)|0)
#define TREMOLO ((70<<4)|0)
#define AUTOPAN ((71<<4)|0)

#define PHASER ((72<<4)|0)
#define PHASER1 ((72<<4)|0)
#define PHASER2 ((72<<4)|8)
#define DISTORTION ((73<<4)|0)
#define OVERDRIVE ((74<<4)|0)
#define AMPSIMULATOR ((75<<4)|0)
#define EQ3BAND ((76<<4)|0)
#define EQ2BAND ((77<<4)|0)
#define AUTOWAH ((78<<4)|0)
#define PITCHCHANGE ((80<<4)|0)
#define AURALEXCITER ((81<<4)|0)
#define TOUCHWAH ((82<<4)|0)
#define TOUCHWAH_DIST ((82<<4)|1)
#define COMPRESSOR ((83<<4)|0)
#define NOISEGATE ((84<<4)|0)
#define VOICECANCEL ((85<<4)|0)

/* indexes into xg_parameter */

/* parameter 1 - 3 */
#define REVERB_TIME 0x02
#define LFO_DEPTH 0x03
#define INITIAL_DELAY 0x04

#define INSERTION_REVERB_TIME 0x02
#define INSERTION_LFO_DEPTH 0x03
#define INSERTION_INITIAL_DELAY 0x04

#define VARIATION_REVERB_TIME 0x42
#define VARIATION_LFO_DEPTH 0x44
#define VARIATION_INITIAL_DELAY 0x46

/* parameter 10 */
#define DRY_LEVEL 0x0B
#define VARIATION_DRY_LEVEL 0x54
#define INSERTION_DRY_LEVEL 0x0B

/* parameter 13 */
#define ER_BALANCE 0x12
#define VARIATION_ER_BALANCE 0x72
#define INSERTION_ER_BALANCE 0x22

#define SYSTEM_VARIATION_CONNECTION 0x05A
#define VARIATION_PART 0x05B
#define INSERTION_PART 0x0C

