/*
---------------------------------------------------------------------------
Open Asset Import Library (assimp)
---------------------------------------------------------------------------

Copyright (c) 2006-2026, assimp team

All rights reserved.

Redistribution and use of this software in source and binary forms,
with or without modification, are permitted provided that the following
conditions are met:

* Redistributions of source code must retain the above
copyright notice, this list of conditions and the
following disclaimer.

* Redistributions in binary form must reproduce the above
copyright notice, this list of conditions and the
following disclaimer in the documentation and/or other
materials provided with the distribution.

* Neither the name of the assimp team, nor the names of its
contributors may be used to endorse or promote products
derived from this software without specific prior
written permission of the assimp team.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
---------------------------------------------------------------------------
*/

#include "UnitTestPCH.h"

#include <assimp/postprocess.h>
#include <assimp/scene.h>
#include <assimp/Importer.hpp>

using namespace Assimp;

TEST(utMD5Importer, importEmpty) {
    Assimp::Importer importer;
    const aiScene *scene = importer.ReadFile(ASSIMP_TEST_MODELS_DIR "/MD5/invalid/empty.md5mesh", aiProcess_ValidateDataStructure);
    ASSERT_EQ(nullptr, scene);
}

TEST(utMD5Importer, importSimpleCube) {
    Assimp::Importer importer;
    const aiScene *scene = importer.ReadFile(ASSIMP_TEST_MODELS_DIR "/MD5/SimpleCube.md5mesh", aiProcess_ValidateDataStructure);
    ASSERT_NE(nullptr, scene);
}

TEST(utMD5Importer, importInvalidBoneIndex) {
    // Regression test: a crafted .md5mesh whose weight references a bone index
    // beyond numJoints used to cause an out-of-bounds heap access in the loader.
    // The importer must reject the file gracefully instead of corrupting memory.
    Assimp::Importer importer;
    const aiScene *scene = importer.ReadFile(ASSIMP_TEST_MODELS_DIR "/MD5/invalid/InvalidBoneIndex.md5mesh", aiProcess_ValidateDataStructure);
    ASSERT_EQ(nullptr, scene);
}

TEST(utMD5Importer, importOverflowingVertexIndex) {
    // Regression test: a vertex index of 0xffffffff makes idx + 1 wrap to zero, so the
    // vertex array is resized to nothing and then indexed with the original value.
    Assimp::Importer importer;
    const aiScene *scene = importer.ReadFile(ASSIMP_TEST_MODELS_DIR "/MD5/invalid/OverflowingVertexIndex.md5mesh", aiProcess_ValidateDataStructure);
    ASSERT_EQ(nullptr, scene);
}

TEST(utMD5Importer, importOverflowingTriangleIndex) {
    // Same wraparound through the triangle index.
    Assimp::Importer importer;
    const aiScene *scene = importer.ReadFile(ASSIMP_TEST_MODELS_DIR "/MD5/invalid/OverflowingTriangleIndex.md5mesh", aiProcess_ValidateDataStructure);
    ASSERT_EQ(nullptr, scene);
}

TEST(utMD5Importer, importOverflowingWeightIndex) {
    // Same wraparound through the weight index.
    Assimp::Importer importer;
    const aiScene *scene = importer.ReadFile(ASSIMP_TEST_MODELS_DIR "/MD5/invalid/OverflowingWeightIndex.md5mesh", aiProcess_ValidateDataStructure);
    ASSERT_EQ(nullptr, scene);
}

TEST(utMD5Importer, importInvalidCameraCut) {
    // Regression test: a crafted .md5camera whose cut list references a frame
    // index past the parsed frame array used to read out of bounds while
    // building the camera animations. The importer must reject it gracefully.
    Assimp::Importer importer;
    const aiScene *scene = importer.ReadFile(ASSIMP_TEST_MODELS_DIR "/MD5/invalid/InvalidCameraCut.md5camera", 0);
    ASSERT_EQ(nullptr, scene);
}

TEST(utMD5Importer, importMalformedWeightIndex) {
    Assimp::Importer importer;
    const aiScene *scene = importer.ReadFile(ASSIMP_TEST_MODELS_DIR "/MD5/malformed_weight_index.md5mesh", aiProcess_ValidateDataStructure);
    ASSERT_EQ(nullptr, scene);
}

TEST(utMD5Importer, importBoarMan) {
    Assimp::Importer importer;
    const aiScene *scene = importer.ReadFile(ASSIMP_TEST_MODELS_NONBSD_DIR "/MD5/BoarMan.md5mesh", aiProcess_ValidateDataStructure);
    ASSERT_NE(nullptr, scene);
}

TEST(utMD5Importer, importBob) {
    Assimp::Importer importer;
    const aiScene *scene = importer.ReadFile(ASSIMP_TEST_MODELS_NONBSD_DIR "/MD5/Bob.md5mesh", aiProcess_ValidateDataStructure);
    ASSERT_NE(nullptr, scene);
}
