/*
---------------------------------------------------------------------------
Open Asset Import Library (assimp)
---------------------------------------------------------------------------

Copyright (c) 2006-2026, assimp team

All rights reserved.

Redistribution and use of this software in source and binary forms,
with or without modification, are permitted provided that the following
conditions are met:

* Redistributions of source code must retain the above
copyright notice, this list of conditions and the
following disclaimer.

* Redistributions in binary form must reproduce the above
copyright notice, this list of conditions and the
following disclaimer in the documentation and/or other
materials provided with the distribution.

* Neither the name of the assimp team, nor the names of its
contributors may be used to endorse or promote products
derived from this software without specific prior
written permission of the assimp team.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
---------------------------------------------------------------------------
*/
#include "AbstractImportExportBase.h"
#include "UnitTestPCH.h"
#include <assimp/postprocess.h>
#include <assimp/scene.h>
#include <assimp/Importer.hpp>

using namespace Assimp;

class utRAWImportExport : public AbstractImportExportBase {
public:
    virtual bool importerTest() {
        Assimp::Importer importer;
        const aiScene *scene = importer.ReadFile(ASSIMP_TEST_MODELS_DIR "/RAW/Wuson.raw", aiProcess_ValidateDataStructure);
#ifndef ASSIMP_BUILD_NO_RAW_IMPORTER
        return nullptr != scene;
#else
        return nullptr == scene;
#endif
    }
};

TEST_F(utRAWImportExport, importSimpleRAWTest) {
    EXPECT_TRUE(importerTest());
}


TEST_F(utRAWImportExport, importInvalid) {
    Assimp::Importer importer;
    int flags = 0;
    flags |= aiProcess_ValidateDataStructure;

    const aiScene *scene = importer.ReadFile(ASSIMP_TEST_MODELS_DIR "/invalid/empty.raw", flags);
    ASSERT_EQ(scene, nullptr);
}


TEST_F(utRAWImportExport, importColor) {
    Assimp::Importer importer;
    int flags = 0;
    flags |= aiProcess_ValidateDataStructure;

    const aiScene *scene = importer.ReadFile(ASSIMP_TEST_MODELS_DIR "/RAW/WithColor.raw", flags);
#ifndef ASSIMP_BUILD_NO_RAW_IMPORTER
    ASSERT_NE(scene, nullptr);
#else  // ASSIMP_BUILD_NO_RAW_IMPORTER
    ASSERT_EQ(scene, nullptr);
#endif  // ASSIMP_BUILD_NO_RAW_IMPORTER
}


TEST_F(utRAWImportExport, importTexture) {
    Assimp::Importer importer;
    int flags = 0;
    flags |= aiProcess_ValidateDataStructure;

    const aiScene *scene = importer.ReadFile(ASSIMP_TEST_MODELS_DIR "/RAW/WithTexture.raw", flags);
#ifndef ASSIMP_BUILD_NO_RAW_IMPORTER
    ASSERT_NE(scene, nullptr);
#else  // ASSIMP_BUILD_NO_RAW_IMPORTER
    ASSERT_EQ(scene, nullptr);
#endif  // ASSIMP_BUILD_NO_RAW_IMPORTER
}
