# PCE source code
The PCE is part of Intel(R) Software Guard Extensions for Linux\* OS which is published in [linux-sgx](https://github.com/intel/confidential-computing.sgx/) Github repository. The libsgx_pce.signed.so in prebuilt package is built by [pce](https://github.com/intel/confidential-computing.sgx/tree/main/psw/ae/pce) with branch [sgx_2.25_reproducible](https://github.com/intel/confidential-computing.sgx/tree/sgx_2.25_reproducible) and signed by Intel.

# QE3 source code
The QE3 is part of [Intel(R) Software Guard Extensions Data Center Attestation Primitives](https://github.com/intel/confidential-computing.tee.dcap/) Github repository. The libsgx_qe3.signed.so in prebuilt package is built by [qe3](https://github.com/intel/confidential-computing.tee.dcap/tree/main/QuoteGeneration/quote_wrapper/quote/enclave) with branch [sgx_2.25_reproducible](https://github.com/intel/confidential-computing.sgx/tree/sgx_2.25_reproducible) and signed by Intel.

# QVE source code
The QVE is part of [Intel(R) Software Guard Extensions Data Center Attestation Primitives](https://github.com/intel/confidential-computing.tee.dcap/) Github repository. The libsgx_qve.signed.so in prebuilt package is built by [qve](https://github.com/intel/confidential-computing.tee.dcap/tree/main/QuoteVerification/QvE/Enclave) with branch [sgx_2.27_reproducible](https://github.com/intel/confidential-computing.sgx/tree/sgx_2.27_reproducible)and signed by Intel.

# IDE source code
The IDE is part of [Intel(R) Software Guard Extensions Data Center Attestation Primitives](https://github.com/intel/confidential-computing.tee.dcap/) Github repository. The libsgx_id_enclave.signed.so in prebuilt package is built by [id_enclave](https://github.com/intel/confidential-computing.tee.dcap/tree/main/QuoteGeneration/quote_wrapper/quote/id_enclave) with branch [sgx_2.25_reproducible](https://github.com/intel/confidential-computing.sgx/tree/sgx_2.25_reproducible) and signed by Intel.

# TDQE source code
The TDQE is part of [Intel(R) Software Guard Extensions Data Center Attestation Primitives](https://github.com/intel/confidential-computing.tee.dcap/) Github repository. The libsgx_tdqe.signed.so in prebuilt package is built by [tdqe](https://github.com/intel/confidential-computing.tee.dcap/tree/main/QuoteGeneration/quote_wrapper/tdx_quote/enclave) with branch [sgx_2.25_reproducible](https://github.com/intel/confidential-computing.sgx/tree/sgx_2.25_reproducible) and signed by Intel.
