// org.kde.plasma.desktop-layout.js

loadTemplate("org.kde.plasma.desktop.defaultPanel");

// wallpaper
let desktopsArray = desktopsForActivity(currentActivity());
for (let j = 0; j < desktopsArray.length; j++) {
    desktopsArray[j].wallpaperPlugin = "org.kde.image";
    desktopsArray[j].wallpaperConfig = desktopsArray[j].wallpaperConfig || {};
    desktopsArray[j].wallpaperConfig.Image =
    "/usr/share/wallpapers/Oreon11/contents/images/3840x2160.jpg";
}

// panel tweaks
let ps = panels();
for (let i = 0; i < ps.length; i++) {
    let p = ps[i];
    if (p.location === "bottom") {
        // no floating
        p.floating = false;

        // IMPORTANT: disable adaptive behavior
        // 0 = Always visible background (non-adaptive)
        p.backgroundHints = 0;

        // system tray defaults
        let tray =
        p.widgetById("org.kde.plasma.systemtray") ||
        p.addWidget("org.kde.plasma.systemtray");

        tray.currentConfigGroup = ["General"];
        tray.writeConfig(
            "shownItems",
            "org.kde.plasma.volume,org.kde.plasma.keyboardlayout,org.kde.plasma.networkmanagement,org.kde.plasma.battery"
        );
        tray.writeConfig(
            "hiddenItems",
            "org.kde.plasma.notifications,org.kde.plasma.clipboard,org.kde.plasma.bluetooth,org.kde.plasma.printmanager,org.kde.plasma.devicenotifier,org.kde.plasma.removabledevices"
        );
    }
}
